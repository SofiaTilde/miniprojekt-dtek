#ifndef _P32XXXX_H
#define _P32XXXX_H

#ifndef _XC_H
#include <xc.h>

/* For backwards compatibility */
#define __C32_UART __XC_UART

#endif

#endif /* _P32XXXX_H */

